<?php
$page_title = 'Berita & Artikel';
require_once 'includes/db.php';
require_once 'includes/header.php';

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$where = $search ? "WHERE judul LIKE '%$search%' OR isi LIKE '%$search%'" : '';
$beritas = mysqli_query($conn, "SELECT * FROM berita $where ORDER BY created_at DESC");
?>

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<div class="page-hero">
    <div class="container">
        <h1>Berita & Artikel</h1>
        <p>Informasi terkini seputar kegiatan dan perkembangan jurusan</p>
        <div class="breadcrumb">
            <a href="index.php">Home</a> <span>›</span> <span>Berita</span>
        </div>
    </div>
</div>

<section>
    <div class="container">
        <!-- Search Bar -->
        <div class="search-wrapper">
            <form method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari berita atau artikel..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit">
    <i class="bi bi-search"></i>
    Cari
</button>
            </form>
        </div>

        <!-- Berita Terbaru Section -->
        <div class="section-header">
            <div class="section-tag">
    <i class="bi bi-newspaper"></i>
    Berita Terkini
</div>
            <h2>Berita & Kegiatan</h2>
            <div class="divider"></div>
        </div>

        <div class="berita-grid">
            <?php if(mysqli_num_rows($beritas) > 0): ?>
                <?php while($b = mysqli_fetch_assoc($beritas)): ?>
                <div class="berita-card-modern">
                    <div class="berita-badge"><?= htmlspecialchars($b['kategori']) ?></div>
                    <div class="berita-img-modern">
                        <?php if(!empty($b['gambar']) && file_exists('images/'.$b['gambar'])): ?>
                            <img src="images/<?= $b['gambar'] ?>" alt="<?= $b['judul'] ?>">
                        <?php else: ?>
                            <div class="img-placeholder">
    <i class="bi bi-newspaper"></i>
</div>
                        <?php endif; ?>
                    </div>
                    <div class="berita-body">
                        <div class="berita-meta">
                            <span class="berita-date">
    <i class="bi bi-calendar-event"></i>
    <?= date('d M Y', strtotime($b['created_at'])) ?>
</span>

<span class="berita-author">
    <i class="bi bi-person-circle"></i>
    <?= htmlspecialchars($b['penulis']) ?>
</span>
                        </div>
                        <h3><?= htmlspecialchars($b['judul']) ?></h3>
                        <p><?= htmlspecialchars(substr($b['excerpt'], 0, 120)) ?>...</p>
                        <a href="berita_detail.php?slug=<?= urlencode($b['slug']) ?>"
class="berita-link-modern">
    Baca Selengkapnya
    <i class="bi bi-arrow-right"></i>
</a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">
    <i class="bi bi-inbox"></i>
</div>
                    <p>Belum ada berita. Silakan cek lagi nanti.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- CSS untuk halaman berita -->
<style>
/* ===== BERITA PAGE STYLES ===== */
.search-wrapper {
    max-width: 500px;
    margin: -40px auto 40px;
    position: relative;
    z-index: 2;
}
.search-form {
    display: flex;
    gap: 10px;
    background: var(--bg-card);
    padding: 5px;
    border-radius: 60px;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
}
.search-form input {
    flex: 1;
    padding: 12px 20px;
    border: none;
    background: transparent;
    color: var(--text);
    font-size: 0.9rem;
}
.search-form input:focus {
    outline: none;
}
.search-form button {
    background: var(--primary);
    border: none;
    padding: 0 25px;
    border-radius: 50px;
    color: white;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}
.search-form button:hover {
    background: var(--primary-dark);
    transform: scale(0.98);
}

.berita-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.berita-card-modern {
    background: var(--bg-card);
    border-radius: 20px;
    overflow: hidden;
    transition: var(--transition);
    border: 1px solid var(--border);
    position: relative;
}

.berita-card-modern:hover {
    transform: translateY(-8px);
    border-color: var(--primary);
    box-shadow: var(--shadow-md);
}

.berita-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: var(--primary);
    color: white;
    padding: 4px 12px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
    z-index: 2;
}

.berita-img-modern {
    height: 200px;
    overflow: hidden;
    background: var(--primary-soft);
}

.berita-img-modern img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s;
}

.berita-card-modern:hover .berita-img-modern img {
    transform: scale(1.05);
}

.img-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.berita-body {
    padding: 20px;
}

.berita-meta {
    display: flex;
    gap: 15px;
    margin-bottom: 12px;
    font-size: 0.7rem;
    color: var(--text-muted);
}

.berita-date, .berita-author {
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.berita-body h3 {
    font-size: 1.1rem;
    margin-bottom: 12px;
    line-height: 1.4;
    color: var(--text-dark);
    font-family: 'Playfair Display', serif;
}

.berita-body p {
    color: var(--text-light);
    font-size: 0.85rem;
    line-height: 1.5;
    margin-bottom: 16px;
}

.berita-link-modern {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: gap 0.3s;
}

.berita-link-modern:hover {
    gap: 10px;
    color: var(--primary-dark);
}

.empty-state {
    grid-column: 1/-1;
    text-align: center;
    padding: 60px;
    background: var(--bg-card);
    border-radius: 24px;
    border: 1px dashed var(--border);
}
.empty-icon {
    font-size: 4rem;
    margin-bottom: 16px;
}

@media (max-width: 992px) {
    .berita-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}
@media (max-width: 768px) {
    .berita-grid {
        grid-template-columns: 1fr;
    }
    .search-wrapper {
        margin-top: -20px;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>