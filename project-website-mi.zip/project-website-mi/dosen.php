<?php
$page_title = 'Data Dosen';
require_once 'includes/db.php';
require_once 'includes/header.php';

// Ambil data dosen dari database
$dosens = mysqli_query($conn, "SELECT * FROM dosen ORDER BY urutan ASC, nama ASC");
$total_dosen = mysqli_num_rows($dosens);

// Hitung statistik
$s3_count = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM dosen WHERE gelar_belakang LIKE '%Dr.%' OR gelar_depan LIKE '%Dr.%'"))[0];
$bidang_keahlian = mysqli_query($conn, "SELECT bidang_keahlian FROM dosen");
$bidang_list = [];
while($row = mysqli_fetch_assoc($bidang_keahlian)) {
    if(!empty($row['bidang_keahlian'])) {
        $bidang_list[] = $row['bidang_keahlian'];
    }
}
$unique_bidang = count(array_unique($bidang_list));
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- PAGE HERO -->
<div class="page-hero dosen-hero">
    <div class="dosen-hero__bg-pattern"></div>
    <div class="container dosen-hero__inner">
        <div class="dosen-hero__badge">
            <i class="bi bi-mortarboard-fill"></i>
            <span>Tenaga Pendidik</span>
        </div>
        <h1 class="dosen-hero__title">Data Dosen</h1>
        <p class="dosen-hero__sub">Tenaga pengajar profesional dan berpengalaman di bidangnya</p>
        <div class="breadcrumb dosen-hero__breadcrumb">
            <a href="index.php">Home</a>
            <span>›</span>
            <span>Dosen</span>
        </div>
    </div>
</div>

<section class="dosen-section">
    <div class="container">

        <!-- Statistik Bar -->
        <div class="stats-row">
            <div class="stat-card-simple">
                <div class="stat-icon"><i class="bi bi-people-fill"></i></div>
                <div class="stat-number"><?= $total_dosen ?></div>
                <div class="stat-label">Total Dosen</div>
            </div>
            <div class="stat-card-simple">
                <div class="stat-icon"><i class="bi bi-award-fill"></i></div>
                <div class="stat-number"><?= $s3_count ?></div>
                <div class="stat-label">Bergelar Doktor</div>
            </div>
            <div class="stat-card-simple">
                <div class="stat-icon"><i class="bi bi-grid-fill"></i></div>
                <div class="stat-number"><?= $unique_bidang ?></div>
                <div class="stat-label">Bidang Keahlian</div>
            </div>
            <div class="stat-card-simple">
                <div class="stat-icon"><i class="bi bi-journal-richtext"></i></div>
                <div class="stat-number">50+</div>
                <div class="stat-label">Publikasi Ilmiah</div>
            </div>
        </div>

        <!-- Search Box -->
        <div class="search-wrap">
            <div class="search-box">
                <i class="bi bi-search search-box__icon"></i>
                <input type="text" id="dosenSearch" placeholder="Cari nama atau bidang keahlian dosen...">
            </div>
        </div>

        <!-- Dosen Grid -->
        <div class="dosen-grid" id="dosenGrid">
            <?php if($total_dosen > 0): ?>
                <?php
                $avatars = [
                    'bi-person-workspace',
                    'bi-mortarboard',
                    'bi-person-badge',
                    'bi-person-circle'
                ];
                $i = 0;
                while($d = mysqli_fetch_assoc($dosens)):
                    $nama_lengkap = trim(($d['gelar_depan'] ?? '') . ' ' . $d['nama'] . ' ' . ($d['gelar_belakang'] ?? ''));
                    $nama_lengkap = preg_replace('/\s+/', ' ', $nama_lengkap);
                ?>
                <div class="dosen-card-modern" data-name="<?= strtolower(htmlspecialchars($nama_lengkap)) ?>" data-bidang="<?= strtolower(htmlspecialchars($d['bidang_keahlian'] ?? '')) ?>">
                    <div class="dosen-avatar-modern">
                        <?php if(!empty($d['foto']) && file_exists('images/'.$d['foto'])): ?>
                            <img src="images/<?= htmlspecialchars($d['foto']) ?>" alt="<?= htmlspecialchars($d['nama']) ?>">
                        <?php else: ?>
                            <div class="avatar-placeholder">
                                <i class="bi <?= $avatars[$i % count($avatars)] ?>"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="dosen-info">
                        <h3><?= htmlspecialchars($nama_lengkap) ?></h3>
                        <div class="dosen-jabatan"><?= htmlspecialchars($d['jabatan'] ?? 'Dosen Tetap') ?></div>
                        <div class="dosen-meta">
                            <div class="dosen-nidn">
                                <i class="bi bi-credit-card-2-front"></i>
                                <span>NIDN: <?= htmlspecialchars($d['nidn'] ?? '-') ?></span>
                            </div>
                            <div class="dosen-bidang">
                                <i class="bi bi-book"></i>
                                <span><?= htmlspecialchars($d['bidang_keahlian'] ?? '-') ?></span>
                            </div>
                            <div class="dosen-email">
                                <i class="bi bi-envelope"></i>
                                <span><?= htmlspecialchars($d['email'] ?? '-') ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $i++;
                endwhile;
                ?>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">👨‍🏫</div>
                    <p>Belum ada data dosen. Silakan tambahkan melalui admin panel.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Empty search result -->
        <div class="search-empty" id="searchEmpty" style="display:none;">
            <div class="empty-icon">🔍</div>
            <p>Tidak ditemukan dosen yang cocok dengan pencarian Anda.</p>
        </div>

    </div>
</section>

<style>
/* ============================================
   DOSEN PAGE — POLISHED STYLES
   ============================================ */

/* --- Hero --- */
.dosen-hero {
    position: relative;
    overflow: hidden;
}

.dosen-hero__bg-pattern {
    position: absolute;
    inset: 0;
    background-image:
        radial-gradient(circle at 15% 50%, rgba(255,255,255,0.06) 0%, transparent 50%),
        radial-gradient(circle at 85% 20%, rgba(255,255,255,0.06) 0%, transparent 45%);
    pointer-events: none;
}

.dosen-hero__inner {
    position: relative;
    z-index: 1;
}

.dosen-hero__badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.25);
    color: #fff;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    padding: 5px 14px;
    border-radius: 30px;
    margin-bottom: 16px;
    backdrop-filter: blur(4px);
}

.dosen-hero__title {
    font-size: clamp(2rem, 5vw, 3.2rem);
    font-weight: 800;
    margin-bottom: 10px;
}

.dosen-hero__sub {
    font-size: 1rem;
    opacity: 0.85;
    margin-bottom: 20px;
}

.dosen-hero__breadcrumb {
    margin-top: 4px;
}

/* --- Section spacing --- */
.dosen-section {
    padding: 60px 0 80px;
}

/* --- Stats Row --- */
.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 48px;
}

.stat-card-simple {
    background: var(--bg-card);
    border-radius: 18px;
    padding: 24px 20px;
    text-align: center;
    border: 1px solid var(--border);
    transition: var(--transition);
}

.stat-card-simple:hover {
    transform: translateY(-4px);
    border-color: var(--primary);
    box-shadow: 0 8px 24px rgba(0,0,0,0.07);
}

.stat-icon {
    font-size: 1.5rem;
    color: var(--primary);
    margin-bottom: 10px;
    opacity: 0.85;
}

.stat-number {
    font-size: 2rem;
    font-weight: 800;
    color: var(--primary);
    font-family: 'Playfair Display', serif;
    line-height: 1;
}

.stat-label {
    font-size: 0.78rem;
    color: var(--text-muted);
    margin-top: 8px;
    font-weight: 500;
}

/* --- Search Box --- */
.search-wrap {
    margin-bottom: 40px;
}

.search-box {
    position: relative;
    max-width: 520px;
    margin: 0 auto;
}

.search-box__icon {
    position: absolute;
    left: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-muted);
    font-size: 1rem;
    pointer-events: none;
}

.search-box input {
    width: 100%;
    padding: 14px 20px 14px 46px;
    border-radius: 50px;
    border: 1.5px solid var(--border);
    background: var(--bg-card);
    color: var(--text-dark);
    font-size: 0.9rem;
    transition: border-color 0.2s, box-shadow 0.2s;
    outline: none;
    box-sizing: border-box;
}

.search-box input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(var(--primary-rgb, 79,70,229), 0.1);
}

.search-box input::placeholder {
    color: var(--text-muted);
}

/* --- Dosen Grid --- */
.dosen-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 28px;
}

/* --- Dosen Card --- */
.dosen-card-modern {
    background: var(--bg-card);
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    transition: transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease;
    animation: fadeInUp 0.45s ease forwards;
    opacity: 0;
}

.dosen-card-modern:hover {
    transform: translateY(-6px);
    border-color: var(--primary);
    box-shadow: 0 12px 32px rgba(0,0,0,0.09);
}

/* Avatar area */
.dosen-avatar-modern {
    height: 180px;
    background: linear-gradient(135deg, var(--primary-soft, #ede9fe), var(--secondary-soft, #e0f2fe));
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.dosen-avatar-modern img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: top center;
}

.avatar-placeholder {
    font-size: 3.5rem;
    color: var(--primary);
    opacity: 0.55;
}

/* Info area */
.dosen-info {
    padding: 20px 20px 22px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.dosen-info h3 {
    font-size: 1rem;
    font-weight: 700;
    margin: 0 0 4px;
    color: var(--text-dark);
    font-family: 'Playfair Display', serif;
    line-height: 1.35;
}

.dosen-jabatan {
    font-size: 0.78rem;
    font-weight: 600;
    color: var(--primary);
    margin-bottom: 14px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

/* Meta rows */
.dosen-meta {
    display: flex;
    flex-direction: column;
    gap: 7px;
    margin-top: auto;
    border-top: 1px solid var(--border);
    padding-top: 14px;
}

.dosen-nidn,
.dosen-bidang,
.dosen-email {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    font-size: 0.8rem;
    color: var(--text-light);
    line-height: 1.4;
}

.dosen-nidn i,
.dosen-bidang i,
.dosen-email i {
    font-size: 0.85rem;
    color: var(--primary);
    opacity: 0.7;
    flex-shrink: 0;
    margin-top: 1px;
}

.dosen-bidang span {
    background: var(--primary-soft);
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.76rem;
    font-weight: 500;
    color: var(--primary);
}

/* --- Empty States --- */
.empty-state,
.search-empty {
    grid-column: 1 / -1;
    text-align: center;
    padding: 64px 40px;
    background: var(--bg-card);
    border-radius: 20px;
    border: 1.5px dashed var(--border);
}

.search-empty {
    margin-top: 20px;
}

.empty-icon {
    font-size: 3.5rem;
    margin-bottom: 14px;
}

.empty-state p,
.search-empty p {
    font-size: 0.95rem;
    color: var(--text-muted);
    margin: 0;
}

/* --- Staggered Animation --- */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(28px); }
    to   { opacity: 1; transform: translateY(0); }
}

.dosen-card-modern:nth-child(1)  { animation-delay: 0.04s; }
.dosen-card-modern:nth-child(2)  { animation-delay: 0.08s; }
.dosen-card-modern:nth-child(3)  { animation-delay: 0.12s; }
.dosen-card-modern:nth-child(4)  { animation-delay: 0.16s; }
.dosen-card-modern:nth-child(5)  { animation-delay: 0.20s; }
.dosen-card-modern:nth-child(6)  { animation-delay: 0.24s; }
.dosen-card-modern:nth-child(7)  { animation-delay: 0.28s; }
.dosen-card-modern:nth-child(8)  { animation-delay: 0.32s; }
.dosen-card-modern:nth-child(9)  { animation-delay: 0.36s; }

/* --- Responsive --- */
@media (max-width: 992px) {
    .dosen-grid  { grid-template-columns: repeat(2, 1fr); }
    .stats-row   { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 600px) {
    .dosen-grid  { grid-template-columns: 1fr; gap: 20px; }
    .stats-row   { grid-template-columns: repeat(2, 1fr); gap: 14px; }
    .dosen-section { padding: 40px 0 60px; }
    .search-box input { font-size: 0.85rem; }
}
</style>

<script>
/* Live search filter */
(function () {
    const input  = document.getElementById('dosenSearch');
    const grid   = document.getElementById('dosenGrid');
    const empty  = document.getElementById('searchEmpty');
    if (!input || !grid) return;

    input.addEventListener('input', function () {
        const q = this.value.trim().toLowerCase();
        const cards = grid.querySelectorAll('.dosen-card-modern');
        let visible = 0;

        cards.forEach(function (card) {
            const name   = card.dataset.name   || '';
            const bidang = card.dataset.bidang || '';
            const match  = !q || name.includes(q) || bidang.includes(q);
            card.style.display = match ? '' : 'none';
            if (match) visible++;
        });

        if (empty) empty.style.display = (visible === 0 && q) ? 'block' : 'none';
    });
})();
</script>

<?php require_once 'includes/footer.php'; ?>