<?php
/**
 * galeri.php  (halaman depan — di root project-website-mi\)
 * Galeri Kegiatan — MI POLSRI
 */

$page_title = 'Galeri Kegiatan';
require_once 'includes/db.php';
require_once 'includes/header.php';

// Path absolut ke images/ — __DIR__ = root project
define('IMAGE_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR);
define('IMAGE_URL', 'images/');

$galeris = mysqli_query($conn, "SELECT * FROM galeri ORDER BY created_at DESC");
$total   = mysqli_num_rows($galeris);
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- PAGE HERO -->
<div class="page-hero">
    <div class="container">
        <span class="section-tag">
            <i class="bi bi-images"></i> Dokumentasi
        </span>
        <h1>Galeri Kegiatan</h1>
        <p>Dokumentasi kegiatan, seminar, dan workshop<br>Jurusan Manajemen Informatika Polsri</p>

        <?php if ($total > 0): ?>
        <div class="hero-gallery-meta">
            <span><i class="bi bi-image"></i> <?= $total ?> Foto</span>
            <span><i class="bi bi-grid-3x3"></i> 4 Kategori</span>
        </div>
        <?php endif; ?>

        <div class="breadcrumb">
            <a href="index.php">Home</a>
            <span>›</span>
            <span>Galeri</span>
        </div>
    </div>
</div>

<!-- MAIN SECTION -->
<section class="section-gallery">
    <div class="container">

        <!-- Filter Kategori -->
        <div class="filter-gallery">
            <button class="filter-btn active" data-filter="all">
                <i class="bi bi-grid-3x3-gap"></i> Semua
            </button>
            <button class="filter-btn" data-filter="kegiatan">
                <i class="bi bi-people"></i> Kegiatan
            </button>
            <button class="filter-btn" data-filter="seminar">
                <i class="bi bi-mic"></i> Seminar
            </button>
            <button class="filter-btn" data-filter="workshop">
                <i class="bi bi-tools"></i> Workshop
            </button>
            <button class="filter-btn" data-filter="akademik">
                <i class="bi bi-mortarboard"></i> Akademik
            </button>
        </div>

        <!-- Gallery Grid -->
        <div class="gallery-grid-modern" id="galleryGrid">
        <?php
        $ei = 0;
        if ($total > 0):
            while ($g = mysqli_fetch_assoc($galeris)):
                // Normalisasi kategori ke lowercase agar cocok dengan data-filter
                $kategori = strtolower(trim($g['kategori'] ?? 'kegiatan'));

                // Cek file dengan path ABSOLUT, tampilkan dengan URL relatif
                $namaFile = $g['foto'] ?? '';
                $fotoPath = '';
                if ($namaFile !== '' && file_exists(IMAGE_DIR . $namaFile)) {
                    $fotoPath = IMAGE_URL . rawurlencode($namaFile);
                    // rawurlencode agar nama file dengan spasi/kurung tetap terbaca browser
                }

                $delay = ($ei % 6) * 0.07;
        ?>

        <div class="gallery-item" data-cat="<?= htmlspecialchars($kategori) ?>"
             style="animation-delay:<?= $delay ?>s">
            <div class="gallery-card"
                 data-img="<?= $fotoPath ?>"
                 data-title="<?= htmlspecialchars($g['judul']) ?>">

                <!-- Thumbnail -->
                <div class="gallery-thumb-wrap">
                    <?php if ($fotoPath): ?>
                        <img src="<?= $fotoPath ?>"
                             alt="<?= htmlspecialchars($g['judul']) ?>"
                             loading="lazy">
                    <?php else: ?>
                        <div class="gallery-placeholder">
                            <i class="bi bi-image"></i>
                            <span>MI</span>
                        </div>
                    <?php endif; ?>
                    <div class="gallery-overlay">
                        <div class="overlay-content">
                            <i class="bi bi-zoom-in overlay-icon"></i>
                            <span>Lihat Foto</span>
                        </div>
                    </div>
                </div>

                <!-- Info -->
                <div class="gallery-info">
                    <div class="gallery-info-top">
                        <span class="gallery-cat"><?= ucfirst($kategori) ?></span>
                        <div class="gallery-date">
                            <i class="bi bi-calendar3"></i>
                            <?= date('d M Y', strtotime($g['created_at'])) ?>
                        </div>
                    </div>
                    <h3><?= htmlspecialchars($g['judul']) ?></h3>
                    <?php if (!empty($g['deskripsi'])): ?>
                        <p><?= htmlspecialchars($g['deskripsi']) ?></p>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <?php
                $ei++;
            endwhile;
        else:
        ?>

        <div class="empty-gallery">
            <div class="empty-gallery-icon"><i class="bi bi-images"></i></div>
            <h3>Belum Ada Foto</h3>
            <p>Belum ada foto galeri yang ditambahkan.</p>
            <p class="small">Tambahkan foto melalui admin panel.</p>
        </div>

        <?php endif; ?>
        </div><!-- /gallery-grid-modern -->

    </div>
</section>

<!-- LIGHTBOX -->
<div id="lightbox" class="lightbox" role="dialog" aria-modal="true" aria-label="Lihat foto">
    <button class="lightbox-close" aria-label="Tutup">&times;</button>
    <div class="lightbox-inner">
        <img class="lightbox-img" src="" alt="">
        <p class="lightbox-caption"></p>
    </div>
</div>

<style>
.hero-gallery-meta {
    display: inline-flex;
    gap: 1.5rem;
    margin: 1rem 0 0.5rem;
    flex-wrap: wrap;
    justify-content: center;
}
.hero-gallery-meta span {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    padding: 0.3rem 0.9rem;
    border-radius: 100px;
    font-size: 0.78rem;
    color: rgba(255,255,255,0.75);
    backdrop-filter: blur(4px);
}
.hero-gallery-meta i { color: var(--primary-light); font-size: 0.85rem; }

.section-gallery { padding: 4rem 0 5rem; }

.filter-gallery {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 3rem;
}
.filter-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: transparent;
    border: 1px solid var(--border);
    padding: 0.5rem 1.1rem;
    border-radius: 100px;
    font-family: inherit;
    font-size: 0.82rem;
    font-weight: 500;
    cursor: pointer;
    color: var(--text-light);
    transition: background .25s, border-color .25s, color .25s, box-shadow .25s;
}
.filter-btn i { font-size: 0.8rem; }
.filter-btn:hover {
    border-color: var(--primary);
    color: var(--primary);
    background: var(--primary-soft);
}
.filter-btn.active {
    background: var(--primary);
    border-color: var(--primary);
    color: #fff;
    box-shadow: 0 4px 14px rgba(224,142,158,0.3);
}

.gallery-grid-modern {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 1.75rem;
}
.gallery-item {
    opacity: 0;
    animation: fadeInUp 0.5s ease forwards;
}
.gallery-card {
    background: var(--bg-card);
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    transition: transform .3s, border-color .3s, box-shadow .3s;
}
.gallery-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary);
    box-shadow: 0 12px 30px rgba(0,0,0,.3), 0 0 0 1px rgba(224,142,158,.15);
}
.gallery-thumb-wrap {
    position: relative;
    overflow: hidden;
    height: 220px;
    flex-shrink: 0;
}
.gallery-thumb-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform .45s;
}
.gallery-card:hover .gallery-thumb-wrap img { transform: scale(1.06); }

.gallery-placeholder {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 0.4rem;
    color: rgba(255,255,255,0.9);
}
.gallery-placeholder i { font-size: 2.5rem; opacity: .7; }
.gallery-placeholder span {
    font-size: .8rem;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
    opacity: .8;
}

.gallery-overlay {
    position: absolute;
    inset: 0;
    background: rgba(18,10,14,.55);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity .3s;
    backdrop-filter: blur(2px);
}
.gallery-card:hover .gallery-overlay { opacity: 1; }
.overlay-content {
    text-align: center;
    color: #fff;
    transform: translateY(12px);
    transition: transform .3s;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.4rem;
}
.gallery-card:hover .overlay-content { transform: translateY(0); }
.overlay-icon { font-size: 1.8rem; display: block; color: var(--primary-light); }
.overlay-content span { font-size: .82rem; font-weight: 600; letter-spacing: .04em; }

.gallery-info {
    padding: 1.1rem 1.25rem 1.25rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}
.gallery-info-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: .5rem;
    flex-wrap: wrap;
}
.gallery-cat {
    display: inline-block;
    background: var(--primary-soft);
    color: var(--primary);
    padding: .2rem .7rem;
    border-radius: 100px;
    font-size: .65rem;
    font-weight: 600;
    text-transform: capitalize;
    letter-spacing: .03em;
    white-space: nowrap;
}
.gallery-date {
    font-size: .68rem;
    color: var(--text-muted);
    display: inline-flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
}
.gallery-date i { font-size: .7rem; }
.gallery-info h3 {
    font-family: 'Playfair Display', serif;
    font-size: .98rem;
    font-weight: 700;
    color: var(--text-dark);
    line-height: 1.4;
    margin: 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.gallery-info p {
    color: var(--text-light);
    font-size: .78rem;
    line-height: 1.5;
    margin: 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.empty-gallery {
    grid-column: 1 / -1;
    text-align: center;
    padding: 4rem 2rem;
    background: var(--bg-card);
    border-radius: 24px;
    border: 1px dashed var(--border);
}
.empty-gallery-icon {
    width: 80px; height: 80px;
    background: var(--primary-soft);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.25rem;
    font-size: 2rem;
    color: var(--primary);
}
.empty-gallery h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.2rem;
    color: var(--text-dark);
    margin-bottom: .4rem;
}
.empty-gallery p { color: var(--text-light); font-size: .875rem; }
.empty-gallery .small { font-size: .78rem; color: var(--text-muted); margin-top: .3rem; }

.lightbox {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.96);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2000;
    opacity: 0;
    visibility: hidden;
    transition: opacity .3s, visibility .3s;
    padding: 1rem;
}
.lightbox.active { opacity: 1; visibility: visible; }
.lightbox-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
    max-width: 90vw;
}
.lightbox-img {
    max-width: 100%;
    max-height: 80vh;
    object-fit: contain;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0,0,0,.6);
}
.lightbox-caption {
    color: rgba(255,255,255,.65);
    font-size: .82rem;
    text-align: center;
    margin: 0;
    max-width: 500px;
}
.lightbox-close {
    position: absolute;
    top: 1.25rem; right: 1.75rem;
    background: rgba(255,255,255,.08);
    border: 1px solid rgba(255,255,255,.15);
    color: white;
    font-size: 1.5rem;
    width: 42px; height: 42px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background .25s, transform .25s;
}
.lightbox-close:hover {
    background: var(--primary);
    border-color: var(--primary);
    transform: scale(1.08);
}

@media (prefers-reduced-motion: reduce) {
    .gallery-item { opacity: 1 !important; animation: none !important; }
    .gallery-card, .gallery-thumb-wrap img,
    .gallery-overlay, .overlay-content, .lightbox { transition: none !important; }
}
@media (max-width: 1024px) {
    .gallery-grid-modern { grid-template-columns: repeat(2,1fr); gap: 1.25rem; }
}
@media (max-width: 768px) {
    .section-gallery { padding: 2.5rem 0 3.5rem; }
    .filter-gallery { gap: 8px; margin-bottom: 2rem; }
    .filter-btn { padding: .4rem .85rem; font-size: .78rem; }
    .filter-btn i { display: none; }
    .gallery-grid-modern { grid-template-columns: repeat(2,1fr); gap: 1rem; }
    .gallery-thumb-wrap { height: 170px; }
    .gallery-info { padding: .85rem 1rem 1rem; }
}
@media (max-width: 480px) {
    .gallery-grid-modern { grid-template-columns: 1fr; gap: 1rem; }
    .gallery-thumb-wrap { height: 210px; }
}
</style>

<script>
(function () {
    // Filter
    const filterBtns   = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const filter = btn.dataset.filter;
            galleryItems.forEach(item => {
                const match = filter === 'all' || item.dataset.cat === filter;
                if (match) {
                    item.style.display = '';
                    item.style.animation = 'none';
                    item.offsetHeight;
                    item.style.animation = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Lightbox
    const lightbox      = document.getElementById('lightbox');
    const lightboxImg   = document.querySelector('.lightbox-img');
    const lightboxCap   = document.querySelector('.lightbox-caption');
    const lightboxClose = document.querySelector('.lightbox-close');

    function openLightbox(src, title) {
        if (!src) return;
        lightboxImg.src = src;
        lightboxImg.alt = title || '';
        if (lightboxCap) lightboxCap.textContent = title || '';
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeLightbox() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
        lightboxImg.src = '';
    }

    document.querySelectorAll('.gallery-card').forEach(card => {
        card.addEventListener('click', () => {
            const imgSrc = card.dataset.img;
            const title  = card.dataset.title;
            if (imgSrc) openLightbox(imgSrc, title);
        });
    });

    lightboxClose.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && lightbox.classList.contains('active')) closeLightbox();
    });
})();
</script>

<?php require_once 'includes/footer.php'; ?>