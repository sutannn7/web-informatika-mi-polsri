<?php
$page_title = 'Beranda - Manajemen Informatika POLSRI';
require_once 'includes/db.php';
require_once 'includes/header.php';
// FIX: query pertama ($berita_terbaru LIMIT 3) dihapus — tidak dipakai,
// query aktual ada di section news (LIMIT 6).
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<section class="hero hero-beranda">
    <div class="container">

        <!-- Kiri: Konten utama -->
        <div class="hero-content">
            <div class="hero-badge">
                <i class="bi bi-mortarboard-fill"></i>
                Politeknik Negeri Sriwijaya
            </div>

            <h1>Manajemen Informatika<br><span class="hero-title-accent">D4</span></h1>

            <p>
                Program Studi Vokasi unggulan yang menghasilkan tenaga ahli profesional
                di bidang teknologi informasi untuk mendukung efisiensi proses bisnis organisasi.
            </p>

            
            <div class="hero-btns">
                <a href="about.php" class="btn btn-primary">
                    <i class="bi bi-journal-text"></i> Profil Jurusan
                </a>
                <a href="kontak.php" class="btn btn-outline-light">
                    <i class="bi bi-envelope-paper"></i> Hubungi Kami
                </a>
            </div>

            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-number">390+</div>
                    <div class="stat-label">Mahasiswa D4</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">84+</div>
                    <div class="stat-label">Dosen</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">13+</div>
                    <div class="stat-label">Tendik</div>
                </div>
            </div>
        </div>

        <!-- Kanan: Panel visual -->
        <div class="hero-image hero-panel">
            <div class="hero-panel-logo">
                <img src="images/logo-polsri.png" alt="Logo POLSRI">
            </div>
            <h3>Politeknik Negeri Sriwijaya</h3>
            <p>Kampus unggul di bidang vokasi</p>

            <div class="hero-panel-pills">
                <span><i class="bi bi-patch-check-fill"></i> Akreditasi A</span>
                <span><i class="bi bi-globe2"></i> Internasional</span>
                <span><i class="bi bi-building"></i> Vokasi</span>
            </div>
        </div>

    </div>
</section>

<!-- ============================================================
     FEATURE SECTION
     FIX: ditambah class .section-feature agar bisa ditarget CSS
     ============================================================ -->
<section class="section-feature">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">
                <i class="bi bi-stars"></i> Keunggulan
            </span>
            <h2>Mengapa Memilih Kami?</h2>
            <p>Program studi yang dirancang untuk menghasilkan lulusan siap industri</p>
        </div>

        <div class="feature-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-mortarboard"></i>
                </div>
                <h3>Pendidikan Vokasi</h3>
                <p>Kurikulum berbasis outcome yang diakui internasional dengan standar industri terkini.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-globe2"></i>
                </div>
                <h3>Magang & Pertukaran</h3>
                <p>Program magang ke industri dan kampus mitra luar negeri untuk pengalaman global.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-cpu"></i>
                </div>
                <h3>Inovasi Digital</h3>
                <p>Dukungan inkubator bisnis dan kewirausahaan digital bagi mahasiswa berprestasi.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
     VISI MISI SECTION
     FIX: ditambah class .section-visimisi, CSS didefinisikan di bawah
     ============================================================ -->
<section class="section-visimisi">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">
                <i class="bi bi-compass"></i> Arah & Tujuan
            </span>
            <h2>Visi & Misi</h2>
            <p>Landasan nilai dan arah pengembangan program studi</p>
        </div>

        <div class="visi-misi-home">
            <div class="visi-box">
                <div class="visimisi-icon">
                    <i class="bi bi-bullseye"></i>
                </div>
                <div class="visimisi-label">Visi</div>
                <h3>Terdepan di Bidang Vokasi</h3>
                <p>Menjadi penyelenggara pendidikan vokasi yang unggul dan terkemuka di bidang Manajemen Informatika berstandar internasional.</p>
            </div>

            <div class="misi-box">
                <div class="visimisi-icon">
                    <i class="bi bi-diagram-3"></i>
                </div>
                <div class="visimisi-label">Misi</div>
                <h3>Langkah Menuju Keunggulan</h3>
                <ul class="misi-list">
                    <li>
                        <i class="bi bi-check-circle-fill"></i>
                        Pendidikan vokasi berbasis outcome
                    </li>
                    <li>
                        <i class="bi bi-check-circle-fill"></i>
                        Penelitian terapan &amp; kolaborasi internasional
                    </li>
                    <li>
                        <i class="bi bi-check-circle-fill"></i>
                        Magang &amp; pertukaran pelajar ke luar negeri
                    </li>
                    <li>
                        <i class="bi bi-check-circle-fill"></i>
                        Inovasi &amp; kewirausahaan digital
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
     NEWS SECTION
     Query & logic PHP identik — hanya markup dirapikan
     FIX: query $berita_terbaru yang tidak dipakai di atas sudah dihapus
     ============================================================ -->
<section class="section-news">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">
                <i class="bi bi-newspaper"></i> Terbaru
            </span>
            <h2>Berita &amp; Kegiatan Terbaru</h2>
            <p>Informasi terkini seputar kegiatan dan perkembangan jurusan</p>
        </div>

        <div class="news-grid">
            <?php
            $query_berita  = "SELECT * FROM berita WHERE status='published' ORDER BY created_at DESC LIMIT 6";
            $result_berita = mysqli_query($conn, $query_berita);

            if (mysqli_num_rows($result_berita) > 0):
                while ($item = mysqli_fetch_assoc($result_berita)):
                    $judul    = htmlspecialchars($item['judul']);
                    $slug     = $item['slug'];
                    $kategori = htmlspecialchars($item['kategori'] ?? 'Umum');
                    $tanggal  = date('d M Y', strtotime($item['created_at']));
                    $excerpt  = htmlspecialchars(substr($item['excerpt'] ?? strip_tags($item['isi']), 0, 100));
                    $gambar   = (!empty($item['gambar']) && file_exists('images/' . $item['gambar']))
                                ? 'images/' . $item['gambar']
                                : null;
            ?>

            <div class="news-card">
                <div class="news-img">
                    <?php if ($gambar): ?>
                        <img src="<?= $gambar ?>" alt="<?= $judul ?>" loading="lazy">
                    <?php else: ?>
                        <div class="news-img-placeholder">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="news-content">
                    <div class="news-meta">
                        <span class="news-category"><?= $kategori ?></span>
                        <span class="news-date">
                            <i class="bi bi-calendar3"></i> <?= $tanggal ?>
                        </span>
                    </div>
                    <h3><?= $judul ?></h3>
                    <p><?= $excerpt ?>...</p>
                    <a href="berita_detail.php?slug=<?= $slug ?>" class="news-link">
                        Baca Selengkapnya <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
            </div>

            <?php
                endwhile;
            else:
            ?>
                <div class="news-empty">
                    <div class="empty-state-icon">
                        <i class="bi bi-newspaper"></i>
                    </div>
                    <p>Belum ada berita atau kegiatan terbaru.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="text-center mt-4">
            <a href="berita.php" class="btn btn-outline">
                Lihat Semua Berita <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- ============================================================
     CTA SECTION
     FIX: ditambah class .section-cta, CSS didefinisikan di bawah
     ============================================================ -->
<section class="cta-section">
    <div class="container">
        <div class="cta-inner">
            <div class="cta-glow"></div>
            <span class="section-tag cta-tag">
                <i class="bi bi-send"></i> Bergabung Sekarang
            </span>
            <h2>Siap Bergabung dengan POLSRI?</h2>
            <p>
                Jadilah bagian dari keluarga besar Manajemen Informatika D4<br>
                Politeknik Negeri Sriwijaya.
            </p>
            <div class="cta-btns">
                <a href="kontak.php" class="btn btn-primary">
                    <i class="bi bi-send"></i> Hubungi Kami
                </a>
                <a href="about.php" class="btn btn-outline-light">
                    <i class="bi bi-info-circle"></i> Pelajari Lebih Lanjut
                </a>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
     STYLES — semua inline CSS dari hero + class baru didefinisikan di sini
     ============================================================ -->
<style>
/* ── Hero ──────────────────────────────────────────────────── */
/* FIX: background, color, text-shadow sebelumnya semua inline */
.hero-beranda {
    background:
        linear-gradient(rgba(0, 0, 0, 0.62), rgba(0, 0, 0, 0.62)),
        url('images/bg-kampus.jpg') center / cover no-repeat;
}

/* Judul dengan aksen warna primary */
.hero-title-accent {
    color: var(--primary-light);
    font-style: normal;
}

/* Teks hero — override agar kontras di atas foto */
.hero-beranda .hero-content h1 {
    color: #fff;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.45);
}
.hero-beranda .hero-content p {
    color: rgba(255, 255, 255, 0.88);
    text-shadow: 0 1px 6px rgba(0, 0, 0, 0.3);
}

/* FIX: btn-outline-light menggantikan btn-outline + inline style color/border white */
.btn-outline-light {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.5);
    color: #fff;
}
.btn-outline-light:hover {
    background: rgba(255, 255, 255, 0.12);
    border-color: #fff;
    color: #fff;
}

/* Hero panel kanan */
.hero-panel {
    background: rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.4rem;
}
.hero-panel h3 {
    color: #fff;
    font-size: 1rem;
    font-weight: 700;
    margin: 0;
    text-align: center;
}
.hero-panel > p {
    color: rgba(255, 255, 255, 0.7);
    font-size: 0.8rem;
    margin: 0;
    text-align: center;
}

.hero-panel-logo {
    width: 88px;
    height: 88px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0.5rem;
    margin-bottom: 0.5rem;
    border: 1px solid rgba(255, 255, 255, 0.15);
}
.hero-panel-logo img {
    width: 64px;
    height: auto;
    object-fit: contain;
}

/* Pills info di hero panel */
.hero-panel-pills {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-top: 0.75rem;
    width: 100%;
}
.hero-panel-pills span {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: 0.4rem 0.85rem;
    border-radius: 100px;
    font-size: 0.72rem;
    color: rgba(255, 255, 255, 0.8);
    font-weight: 500;
}
.hero-panel-pills i {
    color: var(--primary-light);
    font-size: 0.78rem;
}

/* ── Feature section ───────────────────────────────────────── */
.section-feature {
    padding: 5rem 0;
}

.feature-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.75rem;
    margin-top: 0.5rem;
}

/* FIX: .feature-card tidak terdefinisi di CSS global */
.feature-card {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 2rem 1.75rem;
    text-align: center;
    transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
}
.feature-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary);
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(224, 142, 158, 0.12);
}

/* FIX: .feature-icon tidak terdefinisi di CSS global */
.feature-icon {
    width: 64px;
    height: 64px;
    background: var(--primary-soft);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.25rem;
    font-size: 1.75rem;
    color: var(--primary);
    transition: background 0.3s ease;
}
.feature-card:hover .feature-icon {
    background: rgba(224, 142, 158, 0.25);
}

.feature-card h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--text-dark);
    margin-bottom: 0.6rem;
}
.feature-card p {
    color: var(--text-light);
    font-size: 0.85rem;
    line-height: 1.6;
    margin: 0;
}

/* ── Visi Misi section ─────────────────────────────────────── */
/* FIX: .section-visimisi, .visi-misi-home, .visi-box, .misi-box
        tidak terdefinisi di CSS global */
.section-visimisi {
    padding: 5rem 0;
    background: var(--bg-elevated, #1E1E2A);
}

.visi-misi-home {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.75rem;
    margin-top: 0.5rem;
}

.visi-box,
.misi-box {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 2rem;
    position: relative;
    overflow: hidden;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}
.visi-box:hover,
.misi-box:hover {
    border-color: var(--primary);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
}
/* Garis aksen atas */
.visi-box::before,
.misi-box::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
}

.visimisi-icon {
    width: 48px;
    height: 48px;
    background: var(--primary-soft);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: var(--primary);
    margin-bottom: 0.75rem;
}

.visimisi-label {
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--primary);
    margin-bottom: 0.4rem;
}

.visi-box h3,
.misi-box h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--text-dark);
    margin-bottom: 0.75rem;
}

.visi-box p {
    color: var(--text-light);
    font-size: 0.875rem;
    line-height: 1.7;
    margin: 0;
}

/* Misi list */
.misi-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 0.65rem;
}
.misi-list li {
    display: flex;
    align-items: flex-start;
    gap: 0.6rem;
    font-size: 0.875rem;
    color: var(--text-light);
    line-height: 1.5;
}
.misi-list li i {
    color: var(--primary);
    font-size: 0.8rem;
    margin-top: 3px;
    flex-shrink: 0;
}

/* ── CTA section ───────────────────────────────────────────── */
/* FIX: .cta-section tidak punya CSS — tampil sebagai teks polos */
.cta-section {
    padding: 5rem 0;
    position: relative;
    overflow: hidden;
}

.cta-inner {
    position: relative;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 3.5rem 2.5rem;
    text-align: center;
    overflow: hidden;
}

/* Glow dekoratif di belakang */
.cta-glow {
    position: absolute;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(224, 142, 158, 0.1), transparent 65%);
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    pointer-events: none;
}

.cta-tag {
    margin-bottom: 1.25rem;
}

.cta-inner h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-dark);
    margin-bottom: 0.75rem;
}
.cta-inner p {
    color: var(--text-light);
    font-size: 0.95rem;
    line-height: 1.7;
    margin-bottom: 2rem;
}

.cta-btns {
    display: flex;
    justify-content: center;
    gap: 1rem;
    flex-wrap: wrap;
}

/* btn-outline-light di atas background gelap CTA */
.cta-inner .btn-outline-light {
    border-color: var(--border);
    color: var(--text-light);
}
.cta-inner .btn-outline-light:hover {
    border-color: var(--primary);
    color: var(--primary);
    background: var(--primary-soft);
}

/* ── News empty state ──────────────────────────────────────── */
.news-empty {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem 2rem;
    background: var(--bg-card);
    border-radius: 20px;
    border: 1px dashed var(--border);
    color: var(--text-muted);
}
.news-empty .empty-state-icon {
    width: 64px;
    height: 64px;
    background: var(--primary-soft);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.6rem;
    color: var(--primary);
    margin: 0 auto 1rem;
}

/* ── Responsive ────────────────────────────────────────────── */
@media (max-width: 992px) {
    .feature-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    .visi-misi-home {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .feature-grid {
        grid-template-columns: 1fr;
    }
    .section-feature,
    .section-visimisi,
    .cta-section {
        padding: 3rem 0;
    }
    .cta-inner {
        padding: 2.5rem 1.5rem;
    }
    .cta-inner h2 {
        font-size: 1.5rem;
    }
    .hero-panel-pills {
        flex-direction: row;
        justify-content: center;
        flex-wrap: wrap;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>