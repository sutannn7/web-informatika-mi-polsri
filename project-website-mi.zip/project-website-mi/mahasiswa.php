<?php
$page_title = 'Mahasiswa Berprestasi';
require_once 'includes/db.php';
require_once 'includes/header.php';

$mahasiswas = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY angkatan DESC, nama ASC");
$total      = mysqli_num_rows($mahasiswas);
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- ============================================================
     PAGE HERO
     ============================================================ -->
<div class="page-hero">
    <div class="container">
        <span class="section-tag">
            <i class="bi bi-mortarboard"></i> Civitas Akademika
        </span>
        <h1>Mahasiswa</h1>
        <p>Prestasi, kegiatan, dan organisasi mahasiswa<br>Manajemen Informatika POLSRI</p>

        <?php if ($total > 0): ?>
        <div class="hero-mhs-meta">
            <span><i class="bi bi-people"></i> <?= $total ?> Mahasiswa</span>
            <span><i class="bi bi-trophy"></i> Prestasi</span>
            <span><i class="bi bi-diagram-3"></i> Organisasi</span>
        </div>
        <?php endif; ?>

        <div class="breadcrumb">
            <a href="index.php">Home</a>
            <span>›</span>
            <span>Mahasiswa</span>
        </div>
    </div>
</div>

<!-- ============================================================
     MAIN SECTION
     ============================================================ -->
<section class="section-mahasiswa">
    <div class="container">

        <!-- Filter Tabs -->
        <div class="filter-tabs">
            <button class="filter-tab active" data-filter="all">
                <i class="bi bi-grid-3x3-gap"></i> Semua
            </button>
            <button class="filter-tab" data-filter="prestasi">
                <i class="bi bi-trophy"></i> Prestasi
            </button>
            <button class="filter-tab" data-filter="kegiatan">
                <i class="bi bi-calendar-event"></i> Kegiatan
            </button>
            <button class="filter-tab" data-filter="organisasi">
                <i class="bi bi-diagram-3"></i> Organisasi
            </button>
        </div>

        <!-- Mahasiswa Grid -->
        <div class="mahasiswa-grid" id="mahasiswaGrid">
            <?php
            $icons = ['MI', 'MI', 'MI', 'MI', 'MI'];
            $i     = 0;
            if ($total > 0):
                while ($m = mysqli_fetch_assoc($mahasiswas)):
                    $prestasi   = !empty($m['prestasi'])   ? $m['prestasi']   : null;
                    $kegiatan   = !empty($m['kegiatan'])   ? $m['kegiatan']   : null;
                    $organisasi = !empty($m['organisasi']) ? $m['organisasi'] : null;
                    $delay      = round(($i % 6) * 0.07, 2);
            ?>

            <div
                class="mahasiswa-card-modern"
                data-prestasi="<?= $prestasi   ? '1' : '0' ?>"
                data-kegiatan="<?= $kegiatan   ? '1' : '0' ?>"
                data-organisasi="<?= $organisasi ? '1' : '0' ?>"
                style="animation-delay: <?= $delay ?>s"
            >
                <!-- Card Header -->
                <div class="card-header">
                    <div class="mhs-avatar">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="mahasiswa-badges">
                        <?php if ($prestasi): ?>
                            <span class="badge badge-prestasi">
                                <i class="bi bi-trophy-fill"></i> Prestasi
                            </span>
                        <?php endif; ?>
                        <?php if ($kegiatan): ?>
                            <span class="badge badge-kegiatan">
                                <i class="bi bi-calendar-check-fill"></i> Kegiatan
                            </span>
                        <?php endif; ?>
                        <?php if ($organisasi): ?>
                            <span class="badge badge-organisasi">
                                <i class="bi bi-diagram-3-fill"></i> Organisasi
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Card Body -->
                <div class="card-body">
                    <h3><?= htmlspecialchars($m['nama']) ?></h3>
                    <div class="nim-angkatan">
                        <span><i class="bi bi-hash"></i> <?= htmlspecialchars($m['nim']) ?></span>
                        <span class="angkatan-pill">Angkatan <?= htmlspecialchars($m['angkatan']) ?></span>
                    </div>

                    <?php if ($prestasi): ?>
                        <div class="detail-item detail-prestasi">
                            <div class="detail-icon detail-icon-prestasi">
                                <i class="bi bi-trophy-fill"></i>
                            </div>
                            <div class="detail-text">
                                <strong>Prestasi</strong>
                                <p><?= htmlspecialchars($prestasi) ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($kegiatan): ?>
                        <div class="detail-item detail-kegiatan">
                            <div class="detail-icon detail-icon-kegiatan">
                                <i class="bi bi-calendar-check-fill"></i>
                            </div>
                            <div class="detail-text">
                                <strong>Kegiatan</strong>
                                <p><?= htmlspecialchars($kegiatan) ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($organisasi): ?>
                        <div class="detail-item detail-organisasi">
                            <div class="detail-icon detail-icon-organisasi">
                                <i class="bi bi-diagram-3-fill"></i>
                            </div>
                            <div class="detail-text">
                                <strong>Organisasi</strong>
                                <p><?= htmlspecialchars($organisasi) ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php
                    $i++;
                endwhile;
            else:
            ?>

            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="bi bi-people"></i>
                </div>
                <h3>Belum Ada Data</h3>
                <p>Belum ada data mahasiswa yang ditambahkan.</p>
                <p class="small">Tambahkan data melalui admin panel.</p>
            </div>

            <?php endif; ?>
        </div>

    </div>
</section>

<!-- ============================================================
     STYLES
     ============================================================ -->
<style>
/* ── Hero tambahan ─────────────────────────────────────────── */
.hero-mhs-meta {
    display: inline-flex;
    gap: 1.5rem;
    margin: 1rem 0 0.5rem;
    flex-wrap: wrap;
    justify-content: center;
}
.hero-mhs-meta span {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.12);
    padding: 0.3rem 0.9rem;
    border-radius: 100px;
    font-size: 0.78rem;
    color: rgba(255, 255, 255, 0.75);
    backdrop-filter: blur(4px);
}
.hero-mhs-meta i {
    color: var(--primary-light);
    font-size: 0.85rem;
}

/* ── Section wrapper ───────────────────────────────────────── */
.section-mahasiswa {
    padding: 4rem 0 5rem;
}

/* ── Filter tabs ───────────────────────────────────────────── */
.filter-tabs {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 3rem;
}

.filter-tab {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: transparent;
    border: 1px solid var(--border);
    padding: 0.5rem 1.1rem;
    border-radius: 100px;
    font-family: inherit;
    font-size: 0.82rem;
    font-weight: 500;
    cursor: pointer;
    color: var(--text-light);
    transition: background 0.25s ease, border-color 0.25s ease,
                color 0.25s ease, box-shadow 0.25s ease;
}
.filter-tab i {
    font-size: 0.8rem;
}
.filter-tab:hover {
    border-color: var(--primary);
    color: var(--primary);
    background: var(--primary-soft);
}
.filter-tab.active {
    background: var(--primary);
    border-color: var(--primary);
    color: #fff;
    box-shadow: 0 4px 14px rgba(224, 142, 158, 0.3);
}

/* ── Grid ──────────────────────────────────────────────────── */
.mahasiswa-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.75rem;
}

/* ── Card ──────────────────────────────────────────────────── */
.mahasiswa-card-modern {
    background: var(--bg-card);
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    animation: fadeInUp 0.5s ease forwards;
    opacity: 0;
    transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
}
.mahasiswa-card-modern:hover {
    transform: translateY(-5px);
    border-color: var(--primary);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(224, 142, 158, 0.12);
}

/* ── Card header ───────────────────────────────────────────── */
/* FIX: dulu pakai var(--secondary-soft) yang tidak terdefinisi */
.card-header {
    background: linear-gradient(135deg,
        rgba(224, 142, 158, 0.12) 0%,
        rgba(107, 158, 143, 0.10) 100%
    );
    border-bottom: 1px solid var(--border);
    padding: 1.1rem 1.25rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.75rem;
    min-height: 72px;
}

/* FIX: dulu hanya teks "MI" — sekarang ikon dalam lingkaran */
.mhs-avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: var(--primary-soft);
    border: 1.5px solid rgba(224, 142, 158, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    color: var(--primary);
    font-size: 1.3rem;
    transition: background 0.25s ease;
}
.mahasiswa-card-modern:hover .mhs-avatar {
    background: rgba(224, 142, 158, 0.25);
}

/* ── Badges ────────────────────────────────────────────────── */
.mahasiswa-badges {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

/* FIX: dulu pakai var(--accent)/var(--tertiary) yang tidak terdefinisi */
.badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 0.2rem 0.6rem;
    border-radius: 100px;
    font-size: 0.62rem;
    font-weight: 600;
    letter-spacing: 0.02em;
    white-space: nowrap;
}
.badge i {
    font-size: 0.6rem;
}

.badge-prestasi {
    background: rgba(224, 142, 158, 0.15);
    color: var(--primary);
    border: 1px solid rgba(224, 142, 158, 0.25);
}
.badge-kegiatan {
    background: rgba(107, 158, 143, 0.15);
    color: var(--secondary);
    border: 1px solid rgba(107, 158, 143, 0.25);
}
.badge-organisasi {
    background: rgba(138, 125, 174, 0.15);
    color: #9B8FCA;
    border: 1px solid rgba(138, 125, 174, 0.25);
}

/* ── Card body ─────────────────────────────────────────────── */
.card-body {
    padding: 1.1rem 1.25rem 1.25rem;
    display: flex;
    flex-direction: column;
    flex: 1;
}

.card-body h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.05rem;
    font-weight: 700;
    color: var(--text-dark);
    line-height: 1.35;
    margin: 0 0 0.6rem;
}

/* FIX: dulu justify-content: space-between — rawan tabrakan di mobile */
.nim-angkatan {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    flex-wrap: wrap;
    margin-bottom: 1rem;
    font-size: 0.7rem;
    color: var(--text-muted);
}
.nim-angkatan i {
    font-size: 0.68rem;
    opacity: 0.7;
}
.angkatan-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid var(--border);
    padding: 0.15rem 0.55rem;
    border-radius: 100px;
    font-size: 0.65rem;
    color: var(--text-muted);
}

/* ── Detail items ──────────────────────────────────────────── */
/* FIX: dulu pakai var(--bg-elevated) yang tidak terdefinisi saat itu */
.detail-item {
    display: flex;
    gap: 0.75rem;
    padding: 0.75rem 0.85rem;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid var(--border);
    border-radius: 12px;
    margin-bottom: 0.6rem;
    transition: background 0.25s ease, border-color 0.25s ease;
}
.detail-item:last-child {
    margin-bottom: 0;
}
.detail-item:hover {
    background: var(--primary-soft);
    border-color: rgba(224, 142, 158, 0.2);
}

/* FIX: dulu hanya huruf "P"/"K"/"O" — sekarang lingkaran ikon */
.detail-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    flex-shrink: 0;
    margin-top: 1px;
}
.detail-icon-prestasi {
    background: rgba(224, 142, 158, 0.15);
    color: var(--primary);
}
.detail-icon-kegiatan {
    background: rgba(107, 158, 143, 0.15);
    color: var(--secondary);
}
.detail-icon-organisasi {
    background: rgba(138, 125, 174, 0.15);
    color: #9B8FCA;
}

.detail-text {
    flex: 1;
    min-width: 0;
}
.detail-text strong {
    display: block;
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--text-muted);
    margin-bottom: 3px;
}
.detail-text p {
    font-size: 0.8rem;
    color: var(--text-light);
    line-height: 1.45;
    margin: 0;
    word-break: break-word;
}

/* ── Empty state ───────────────────────────────────────────── */
/* FIX: class .empty-icon conflict dengan CSS global — ganti ke .empty-state-icon */
.empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 4rem 2rem;
    background: var(--bg-card);
    border-radius: 24px;
    border: 1px dashed var(--border);
}
.empty-state-icon {
    width: 80px;
    height: 80px;
    background: var(--primary-soft);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.25rem;
    font-size: 2rem;
    color: var(--primary);
}
.empty-state h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.15rem;
    color: var(--text-dark);
    margin-bottom: 0.4rem;
}
.empty-state p {
    color: var(--text-light);
    font-size: 0.875rem;
}
.empty-state .small {
    font-size: 0.78rem;
    color: var(--text-muted);
    margin-top: 0.3rem;
}

/* ── Animasi ───────────────────────────────────────────────── */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(28px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* FIX: prefers-reduced-motion — card tidak invisible jika animasi diblokir */
@media (prefers-reduced-motion: reduce) {
    .mahasiswa-card-modern {
        opacity: 1 !important;
        animation: none !important;
    }
    .mahasiswa-card-modern,
    .detail-item,
    .filter-tab {
        transition: none !important;
    }
}

/* ── Responsive ────────────────────────────────────────────── */
@media (max-width: 1024px) {
    .mahasiswa-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.25rem;
    }
}

@media (max-width: 768px) {
    .section-mahasiswa {
        padding: 2.5rem 0 3.5rem;
    }
    .filter-tabs {
        gap: 8px;
        margin-bottom: 2rem;
    }
    .filter-tab {
        padding: 0.4rem 0.85rem;
        font-size: 0.78rem;
    }
    .filter-tab i {
        display: none;
    }
    .mahasiswa-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    .card-body h3 {
        font-size: 0.95rem;
    }
}

@media (max-width: 480px) {
    .mahasiswa-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}
</style>

<!-- ============================================================
     SCRIPTS
     ============================================================ -->
<script>
(function () {
    const filterTabs     = document.querySelectorAll('.filter-tab');
    const mahasiswaCards = document.querySelectorAll('.mahasiswa-card-modern');

    filterTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            /* Update active tab */
            filterTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const filter = tab.dataset.filter;

            mahasiswaCards.forEach(card => {
                const hasPrestasi   = card.dataset.prestasi   === '1';
                const hasKegiatan   = card.dataset.kegiatan   === '1';
                const hasOrganisasi = card.dataset.organisasi === '1';

                let show = false;
                if (filter === 'all')        show = true;
                if (filter === 'prestasi'   && hasPrestasi)   show = true;
                if (filter === 'kegiatan'   && hasKegiatan)   show = true;
                if (filter === 'organisasi' && hasOrganisasi) show = true;

                if (show) {
                    card.style.display = '';
                    /* FIX: re-trigger animasi masuk saat filter berubah */
                    card.style.animation = 'none';
                    card.offsetHeight;   /* force reflow */
                    card.style.animation = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
})();
</script>

<?php require_once 'includes/footer.php'; ?>